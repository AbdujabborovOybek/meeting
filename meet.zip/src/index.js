import React from "react";
import ReactDOM from "react-dom/client";
import { Meet } from "./Meet";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <>
    <Meet />
  </>
);
